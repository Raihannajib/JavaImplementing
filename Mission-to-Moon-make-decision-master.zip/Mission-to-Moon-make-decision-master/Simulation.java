package com.company;
import java.util.ArrayList;

public class Simulation {

    public static int load(ArrayList T) {

        int somme = 0;
        for (int i = 0; i < T.size(); i++) {
            somme += (int)T.get(i)/1000;
        }
        return somme;
    }
}

package com.company;

import javax.swing.*;
import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;

public class Main extends Simulation{



    public static void main(String[] args)  throws Exception {
	// write your code here
        ArrayList Q1 = new ArrayList<>();

        File data1 = new File("phase1.txt");
        Scanner scanner1 = new Scanner(data1);

        while(scanner1.hasNextLine()){
            String produit01 = scanner1.nextLine();
            Scanner produit1 = new Scanner(produit01).useDelimiter("[^0-9]+");
            int quantity1 = produit1.nextInt();
            Q1.add(quantity1);
        }

        int cargo1 = load(Q1);
        System.out.print(cargo1+" \n");

        Scanner input = new Scanner(System.in);
        System.out.print("Enter rocket's cost \n ");
        int c = input.nextInt();
        System.out.print("Enter rocket's factor of explosion \n ");
        double fe = input.nextDouble();
        System.out.print("Enter rocket's facto of crash  \n");
        double fc = input.nextDouble();
        System.out.print("Enter rocket's weight  \n");
        int w = input.nextInt();
        System.out.print("Enter rocket's total weight  \n");
        int tw = input.nextInt();


        Rocket rocket1 = new Rocket(c,fe,fc,w,tw,cargo1);

        if (rocket1.canCarry()){
            System.out.print("Best situation for cargo \n ");
        }else{System.out.print("bad weight \n");}


        if (rocket1.land()){
            System.out.print("rocket crashes  ");
        }else if(rocket1.launch()){
            System.out.print("rocket explodes");
        }else{
            System.out.print("Successfull operation inchallah");
        }


        }

        }






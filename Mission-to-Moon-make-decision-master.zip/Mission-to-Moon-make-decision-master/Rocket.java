package com.company;

public class Rocket implements SpaceShip{   //weight in tonne
    static final double LIMIT = 0.9;
    int cost ;
    double FE ; //explosion factor
    double FC;  //crash factor
    int weight; // weight of rocket
    int maxWeight;
    int cargo; //weight of cargo


    public Rocket(int cost, double FE, double FC, int weight, int maxWeight, int cargo) {
        this.cost = cost;
        this.FE = FE;
        this.FC = FC;
        this.weight = weight;
        this.maxWeight = maxWeight;
        this.cargo = cargo;

    }


    public double COLE() {
        double x =  FE*(this.cargo/(this.maxWeight-this.weight));  //chance of launch explosion
        return  x;
    }


    public double COLC() {
        double y = FC*(this.cargo/(maxWeight-weight));   //chance of landing crach
        return y;
    }

    @Override
    public Boolean launch() {
        if(this.COLE() > LIMIT){
            return false;
        }else{
            return true;
        }
    }

    @Override
    public Boolean land() {
        if (this.COLC() > LIMIT) {
            return false;
        } else {
            return true;
        }
    }

        @Override
    public Boolean canCarry() {
        if((this.cargo+this.weight)-this.maxWeight>0){
            return false;
        }else{
            return true;}
    }

    @Override
    public void carry(int W) {
        this.cargo+= W;
    }
}

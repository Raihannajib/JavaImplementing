package com.company;

public interface SpaceShip {
    public Boolean launch();
    public Boolean land();
    public Boolean canCarry();
    public void carry( int W);

}

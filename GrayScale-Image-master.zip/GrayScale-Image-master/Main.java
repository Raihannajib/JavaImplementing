package com.company;


import java.awt.*;
import java.io.File;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;



public class Main {

    public static void main(String[] args) throws Exception {

           File imagePath = new File("capture.PNG");  //path of image Input
           BufferedImage image =  ImageIO.read(imagePath);      //read image's buffer
           int x = image.getWidth();
           int y = image.getHeight();
           int red , green ,blue,alpha,grayScale;
           BufferedImage imageOutput = new BufferedImage(x,y,BufferedImage.TYPE_INT_ARGB);  //plan of image + image declared in 4bytes ARGB
        // A:Alpha  0:trasparent<=A<=255:opaque OR 0<=A<=1 (float)

        for (int i = 0; i < x; i++) {
            for (int j = 0; j <y ; j++) {

                Color pixelColor = new Color(image.getRGB(i,j));   //get presentation of each Color's pixel
                red = pixelColor.getRed();
                green = pixelColor.getGreen();
                blue = pixelColor.getBlue();
                alpha = pixelColor.getAlpha();

                grayScale  =  (red+green+blue)/3;         //grayScale Algo

                Color gray = new Color(grayScale,grayScale,grayScale,alpha);  //new Color

                imageOutput.setRGB(i,j,gray.getRGB());      //binary construction of new image as Our output
            }
        }

        ImageIO.write(imageOutput,"png",new File("output.png"));   //create image's Output


        }
    }

